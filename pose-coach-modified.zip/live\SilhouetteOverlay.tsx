"use client";

import { useEffect, useRef } from "react";
import { buildSilhouetteShapes, drawSilhouette } from "@/lib/pose-processing";
import type { PoseRepresentation, SilhouetteProjection } from "@/lib/pose-processing";

export interface SilhouetteOverlayProps {
  videoRef: React.RefObject<HTMLVideoElement | null>;
  referencePose: PoseRepresentation | null;
}

/**
 * Draws the target-pose outer body silhouette guide locked to the camera frame.
 * The silhouette is fixed in place from the reference pose so the user's live
 * camera image moves underneath it.
 */
export default function SilhouetteOverlay({ videoRef, referencePose }: SilhouetteOverlayProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video || !referencePose) return;

    if (video.videoWidth > 0 && video.videoHeight > 0) {
      if (canvas.width !== video.videoWidth) canvas.width = video.videoWidth;
      if (canvas.height !== video.videoHeight) canvas.height = video.videoHeight;
    }

    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Project using the reference pose's fixed normalization coordinates.
    // This locks the target silhouette to the camera frame so it never tracks live user movement.
    const projection: SilhouetteProjection = {
      originX: referencePose.normalization.originX * canvas.width,
      originY: referencePose.normalization.originY * canvas.height,
      scale: referencePose.normalization.scale * canvas.height,
    };

    const shapes = buildSilhouetteShapes(referencePose.normalizedLandmarks, projection);

    // Render with soft translucent fill and lowered outline opacity per spec
    drawSilhouette(ctx, shapes, {
      fillColor: "#ffffff",
      fillOpacity: 0.22,
      outlineColor: "#ffffff",
      outlineOpacity: 0.4,
      outlineWidth: 1.5,
      dash: [6, 5],
    });
  }, [videoRef, referencePose]);

  return (
    <canvas
      ref={canvasRef}
      className="pointer-events-none absolute inset-0 h-full w-full object-cover"
    />
  );
}

